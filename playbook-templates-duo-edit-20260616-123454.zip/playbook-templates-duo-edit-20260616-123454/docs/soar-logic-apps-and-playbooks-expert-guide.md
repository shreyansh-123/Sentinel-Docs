# SOAR with Azure Logic Apps & Microsoft Sentinel Playbooks — The Expert Guide

> A deep, practical reference for building, operating, and scaling Security Orchestration, Automation and Response (SOAR) playbooks. Written to take a reader from "I can click around" to "I architect SOAR for the enterprise." Read this end-to-end and you should be able to design and ship production playbooks with confidence and speak credibly in a senior Microsoft security interview.

---

## Table of contents

1. [What SOAR really is](#1-what-soar-really-is)
2. [The Azure SOAR stack](#2-the-azure-soar-stack)
3. [Logic Apps deep dive](#3-logic-apps-deep-dive)
4. [Sentinel playbooks: triggers and patterns](#4-sentinel-playbooks-triggers-and-patterns)
5. [Connectors, authentication and identity](#5-connectors-authentication-and-identity)
6. [Automation rules vs playbooks](#6-automation-rules-vs-playbooks)
7. [Designing robust playbooks](#7-designing-robust-playbooks)
8. [Error handling, retries and idempotency](#8-error-handling-retries-and-idempotency)
9. [Security, RBAC and least privilege](#9-security-rbac-and-least-privilege)
10. [CI/CD, ARM/Bicep and source control](#10-cicd-armbicep-and-source-control)
11. [Monitoring, cost and performance](#11-monitoring-cost-and-performance)
12. [Security use cases with worked examples](#12-security-use-cases-with-worked-examples)
13. [Anti-patterns and gotchas](#13-anti-patterns-and-gotchas)
14. [Interview preparation](#14-interview-preparation)
15. [Glossary](#15-glossary)

---

## 1. What SOAR really is

**SOAR** = Security Orchestration, Automation and Response. Three distinct capabilities people often blur together:

- **Orchestration** — coordinating many tools (SIEM, EDR, identity, ticketing, email, threat intel) into one coherent workflow.
- **Automation** — executing repeatable tasks without a human (enrich, block, isolate, notify).
- **Response** — taking or recommending containment/remediation actions tied to an incident.

The business value is measured in **MTTD/MTTR reduction**, **analyst toil reduction**, and **consistency** (every incident handled the same way, fully audited). A senior practitioner always frames automation decisions in terms of these outcomes, not "because we can automate it."

**Human-in-the-loop vs fully automated:** High-impact actions (disable user, isolate host, block IP at perimeter) usually start as *semi-automated* — the playbook gathers context and posts an approval (Teams/email/incident comment), a human approves, then the action runs. Low-risk enrichment is fully automated. Maturing a SOC means gradually moving actions from manual → semi-automated → automated as trust in the logic grows.

---

## 2. The Azure SOAR stack

| Layer | Component | Role |
|---|---|---|
| SIEM | **Microsoft Sentinel** | Detection (analytics rules), incidents, hunting, UEBA |
| Automation engine | **Azure Logic Apps** | The workflow runtime that *is* a "playbook" |
| Trigger/glue | **Automation rules** | Route incidents/alerts to playbooks, set severity/owner, group, suppress |
| Identity | **Microsoft Entra ID** | Users, service principals, managed identities, Conditional Access |
| Response targets | **Defender XDR, Entra, Exchange, firewalls, ServiceNow, Jira, Teams** | Where actions land |
| Data | **Log Analytics workspace** | Where Sentinel data lives; KQL queries run here |

**Key mental model:** A Sentinel *playbook* is just an **Azure Logic App** whose trigger is a Sentinel connector trigger (incident, alert, or entity). Everything you know about Logic Apps applies directly.

**Consumption vs Standard Logic Apps:**

- **Consumption** — single workflow per Logic App, pay-per-execution, multi-tenant, simplest for most Sentinel playbooks. Historically the default for Sentinel.
- **Standard** — multiple workflows per app, runs on the single-tenant Logic Apps runtime (App Service / Functions runtime), supports VNET integration, private endpoints, local development in VS Code, and stateful/stateless workflows. Preferred when you need network isolation, predictable pricing at scale, or many workflows packaged together.

---

## 3. Logic Apps deep dive

### 3.1 Anatomy of a workflow

- **Trigger** — the single entry point (one per workflow). Types: *polling* (checks a source on a recurrence), *push/webhook* (source calls Logic Apps), *request* (HTTP endpoint), *recurrence* (schedule).
- **Actions** — the steps after the trigger. Connectors, control actions (conditions, loops, scopes), and data operations.
- **Connectors** — managed (Microsoft-hosted, ~1000+) or custom (your own OpenAPI/SOAP). Each connector exposes triggers and/or actions.
- **Workflow Definition Language (WDL)** — the JSON behind the designer. Senior engineers read/edit the **code view** directly; the designer is a convenience layer.

### 3.2 Control actions you must master

- **Condition** — if/else branching.
- **Switch** — multi-branch on a single value (e.g., severity High/Medium/Low).
- **For each** — iterate arrays (e.g., all IP entities in an incident). Runs in parallel by default; set concurrency control when order or rate limits matter.
- **Until** — loop until a condition is met or a timeout/count is hit (polling an async job, waiting for approval).
- **Scope** — group actions; enables structured error handling via `runAfter` and try/catch/finally patterns.
- **Parallel branch** — fan out independent work, then optionally join.

### 3.3 Expressions and data handling

The expression language is function-based. The ones you will use constantly:

```
// Reference data from previous steps
triggerBody()
body('HTTP')
outputs('Compose')
items('For_each')

// String
concat('user: ', variables('upn'))
split(item()?['Address'], '/')
replace(x, 'a', 'b')
toLower(x)

// Collections
length(triggerBody()?['Entities'])
first(body('Get_IPs'))
filter / map via 'Select' and 'Filter array' data operations

// Conditionals & null-safety
if(equals(x, 'High'), 'urgent', 'normal')
coalesce(variables('owner'), 'unassigned')
x?['nested']?['field']   // safe navigation, avoids null errors

// Date/time
utcNow()
addHours(utcNow(), -24)
formatDateTime(utcNow(), 'yyyy-MM-ddTHH:mm:ssZ')
```

**Parse JSON** action + a schema is the cleanest way to make dynamic content available downstream. **Compose** is your scratchpad for building or inspecting an object. Prefer typed **variables** sparingly — they break parallelism (Logic Apps serializes around variable mutations).

### 3.4 Stateful vs stateless (Standard)

- **Stateful** — every run is persisted (inputs/outputs/state), full run history, resumable. Use for long-running, approval-based, or auditable security workflows.
- **Stateless** — no per-action persistence, much faster and cheaper, short-lived. Use for high-volume, low-latency enrichment where you do not need run history.

---

## 4. Sentinel playbooks: triggers and patterns

The Microsoft Sentinel connector provides three trigger types — choosing correctly is a frequent interview question.

| Trigger | Fires on | Gives you | Typical use |
|---|---|---|---|
| **Incident trigger** | An incident is created/updated (via automation rule) | Full incident + all entities + alerts | Most response playbooks; enrichment, comments, containment |
| **Alert trigger** | A scheduled analytics rule produces an alert | The single alert and its entities | Per-alert enrichment before incident grouping |
| **Entity trigger** | Analyst right-clicks an entity (e.g., IP, account) | One entity | On-demand, manual investigation actions |

**Run-time identity:** Incident-triggered playbooks need permission to call back into Sentinel (to add comments, change status). This is granted by giving the playbook's identity the **Microsoft Sentinel Responder** (or Contributor) role on the resource group/workspace, plus running the connection under a managed identity where possible.

**Manual / on-demand playbooks:** For a playbook that must *only* run when an analyst chooses (your user-session-revoke case), use the **incident trigger** or **entity trigger** and run it manually from the incident (Incident > Actions > Run playbook) or via the entity context menu. Do **not** wire it to an automation rule that fires automatically. This is the pattern your `user-session-revoke-playbook.drawio` describes.

---

## 5. Connectors, authentication and identity

### 5.1 Authentication options, ranked

1. **Managed identity (preferred).** No secrets. Two flavors:
   - *System-assigned* — tied to the Logic App lifecycle.
   - *User-assigned* — reusable across many Logic Apps; easier to manage at scale.
   Grant it RBAC/Graph permissions and use it in HTTP actions (`Authentication: Managed Identity`) and supported connectors.
2. **Service principal (app registration).** Client ID + secret/certificate. Use when a connector does not support managed identity. Store the secret in **Key Vault**, never inline.
3. **OAuth delegated connection.** A user signs in once; the connection caches tokens. Risk: tied to a human account that can leave or have its password reset. Avoid for production response actions.
4. **API keys.** For third-party services; store in Key Vault and reference via the Key Vault connector or Key Vault references.

### 5.2 Microsoft Graph permissions cheat sheet (common SOAR actions)

| Action | Permission (application) |
|---|---|
| Revoke user sign-in sessions | `User.RevokeSessions.All` (or `User.ReadWrite.All`) via `revokeSignInSessions` |
| Disable/enable user account | `User.ReadWrite.All` (patch `accountEnabled`) |
| Reset password / require re-registration | `UserAuthenticationMethod.ReadWrite.All` |
| Read sign-in logs for enrichment | `AuditLog.Read.All` |
| Confirm user compromised (risk) | `IdentityRiskyUser.ReadWrite.All` |
| Read group membership | `GroupMember.Read.All` |

Always apply **least privilege**: grant only the specific application permission the playbook needs, admin-consented, and document it.

### 5.3 Defender / device actions

Device isolation, AV scan, restrict app execution, and indicator (IoC) creation are done via the **Microsoft Defender for Endpoint** connector or the Defender XDR / Security Graph APIs. Isolation is a high-impact action — gate it behind approval.

---

## 6. Automation rules vs playbooks

- **Automation rule** is Sentinel-native orchestration: *when* an incident/alert matches conditions, *do* ordered actions — change severity, assign owner, add tags, close, or **run a playbook**. It is the routing layer.
- **Playbook (Logic App)** is the *doing* layer — the actual workflow logic and external calls.

**Best practice:** Keep routing/decisioning in automation rules (cheap, native, ordered, no Logic App run cost) and keep complex multi-step logic in playbooks. Automation rules also let you run *multiple* playbooks in a defined order and apply conditions without editing the playbook.

**Order of execution:** Alert-rule automation → incident creation → incident-creation automation rules (in priority order) → incident-update automation rules on subsequent changes.

---

## 7. Designing robust playbooks

A senior design checklist for every playbook:

1. **Single clear purpose.** One playbook = one outcome (enrich IP, disable user, open ticket). Compose larger flows from small playbooks via automation rules.
2. **Idempotent.** Re-running must not double-act (no duplicate tickets, no repeated emails). Guard with a check ("comment already added?", "ticket already linked?").
3. **Parameterized.** Workspace IDs, recipient lists, thresholds, and resource IDs come from parameters/Key Vault, not hardcoded values — so the same artifact deploys to dev/test/prod.
4. **Observable.** Write a structured incident comment at start and end, and tag the incident with what ran.
5. **Fail safe.** On error, never silently swallow. Post a comment/alert so a human knows automation failed.
6. **Bounded.** Set timeouts on `Until` loops and approval waits; define what happens on timeout.
7. **Auditable.** Capture who/what/when/why in the incident and in logs.

### Reference structure

```
Trigger: When Sentinel incident is created/run manually
  Scope: TRY
    - Parse entities (accounts, IPs, hosts)
    - Enrich (TI lookup, sign-in logs, geo)
    - Decision (severity / risk score / approval)
    - Act (revoke / disable / isolate / block)
    - Notify (email SOC, Teams, ticket)
    - Document (add incident comment, tag)
  Scope: CATCH  (runAfter TRY = Failed/TimedOut)
    - Add incident comment: "Automation failed: <error>"
    - Notify on-call
  Scope: FINALLY (runAfter both)
    - Final status comment
```

---

## 8. Error handling, retries and idempotency

- **`runAfter`** is the foundation of error handling. Every action can run after a previous action's `Succeeded`, `Failed`, `Skipped`, or `TimedOut` status. Set a Catch scope to `runAfter` the Try scope's `Failed`/`TimedOut`.
- **Retry policies** per action: `default` (exponential, 4 retries), `none`, `fixed`, or `exponential` with custom count/interval. Tune for rate-limited APIs (e.g., Graph 429s) — respect `Retry-After`.
- **`Terminate`** action lets you end a run with a chosen status (`Failed` + code/message) so the run history reflects reality.
- **Idempotency keys:** When creating tickets or sending notifications, store/lookup a correlation key (incident ARM ID + action) so a re-run finds the existing artifact instead of creating a new one.
- **Concurrency control:** On `For each`, cap degree of parallelism to avoid hammering downstream APIs; for ordered processing set concurrency = 1.
- **Dead-lettering pattern:** If a critical action fails after retries, write the payload to a queue/storage and alert, so nothing is lost.

---

## 9. Security, RBAC and least privilege

- **Playbook identity:** Prefer **user-assigned managed identity** shared across playbooks; grant it only the roles/Graph permissions required.
- **Sentinel roles:** *Reader*, *Responder* (triage + run playbooks + change incidents), *Contributor* (author rules/playbooks). The Logic App's identity typically needs *Microsoft Sentinel Responder* to comment on/update incidents. Analysts who run playbooks need the **Microsoft Sentinel Playbook Operator** role + the Logic Apps trigger permission.
- **Secrets:** Azure **Key Vault** for all secrets/keys; reference via Key Vault connector or managed-identity-based access. Rotate regularly. Never store secrets in workflow JSON or parameters files committed to git.
- **Network:** For Standard Logic Apps, use VNET integration + private endpoints so traffic to Key Vault/Storage/APIs stays private.
- **Blast-radius control:** High-impact actions behind approval; restrict who can edit/publish production playbooks; require PR review (see CI/CD).
- **Logging:** Send Logic Apps diagnostics to Log Analytics; alert on failed runs and on unexpected high-privilege actions.

---

## 10. CI/CD, ARM/Bicep and source control

Production SOAR is *code*, not click-ops.

- **Export/author as ARM or Bicep.** A Logic App is an ARM resource (`Microsoft.Logic/workflows`). Parameterize connections, workspace IDs, and recipients.
- **Source control** the templates (e.g., this repo). Review changes via merge requests.
- **Environments:** dev → test → prod with environment-specific parameter files. Never edit prod in the portal directly; portal edits drift from source.
- **Pipeline stages:** lint/validate template → deploy to test → run smoke test (trigger a synthetic incident) → manual approval → deploy to prod.
- **Connection handling:** API connections are separate ARM resources; deploy them per environment and reference by resource ID. Authorize managed-identity connections at deploy time.
- **Versioning:** Tag releases; keep a changelog of playbook logic changes for audit.

---

## 11. Monitoring, cost and performance

- **Run history** (Consumption) / **Application Insights + run history** (Standard) for debugging.
- **Diagnostic settings** → Log Analytics; build a workbook of playbook success/failure rates, durations, and action-level errors.
- **Alerts on failures:** Sentinel analytics rule or Azure Monitor alert on failed playbook runs.
- **Cost drivers (Consumption):** number of action executions (each action is billed), connector calls (standard vs enterprise connectors priced differently), and trigger polls. Reduce cost by trimming actions, using stateless where possible, batching, and pushing routing into (free) automation rules.
- **Performance:** parallelize independent enrichment, cap `For each` concurrency to avoid throttling, prefer push triggers over frequent polling.

---

## 12. Security use cases with worked examples

Each example lists trigger, logic, connectors, and the senior-level considerations.

### 12.1 Revoke user sessions on compromise (your playbook)

**Scenario:** Analyst confirms a user's credentials/session are compromised and wants to kill all active sessions immediately.

- **Trigger:** Manual run from the incident (or entity trigger on the Account entity). *Not* auto-run.
- **Logic:**
  1. Parse the Account entity → resolve UPN / object ID.
  2. Validate the user exists and has active sessions (Graph `GET /users/{id}`; optionally check recent sign-ins).
  3. **Action:** `POST /users/{id}/revokeSignInSessions` (Graph). This invalidates refresh tokens and forces re-auth everywhere.
  4. Optionally also set `accountEnabled = false` or confirm risky user, if policy says so (gate behind approval).
  5. **Email** the SOC team (Office 365 Outlook connector) with user, analyst, action, timestamp, result.
  6. **Add incident comment** in Sentinel documenting the action and result.
  7. Handle failure: comment "revoke failed: <error>", notify on-call.
- **Connectors:** Microsoft Sentinel, Microsoft Graph (HTTP + managed identity), Office 365 Outlook.
- **Permissions:** `User.RevokeSessions.All`, Sentinel Responder, Mail.Send (or shared mailbox).
- **Senior notes:** Revoking sessions does **not** reset the password — an attacker who knows the password can sign back in. Real containment usually pairs `revokeSignInSessions` with a password reset and/or `accountEnabled=false` and a Conditional Access block. Make this explicit in the playbook design and the incident comment.

**Graph call (HTTP action, managed identity):**

```http
POST https://graph.microsoft.com/v1.0/users/{userId}/revokeSignInSessions
Authorization: <Managed Identity>
Content-Length: 0
```

### 12.2 Phishing email triage and containment

- **Trigger:** Incident from a phishing analytics rule (or user-reported phish).
- **Logic:** Extract sender, URLs, attachments → detonate URLs/files (Defender / TI) → if malicious: soft-delete the message tenant-wide (Defender for Office / `Search-Mailbox`/`New-ComplianceSearchAction` via Security & Compliance), block sender, add IoCs → notify reporting user → comment & close.
- **Senior notes:** Idempotency matters — the same campaign hits many mailboxes; group by automation rule and act once per campaign, not per email.

### 12.3 Malicious IP / brute-force block

- **Trigger:** Incident with IP entity (e.g., impossible travel, brute force).
- **Logic:** Enrich IP (TI reputation, geo, whois, is-it-a-known-VPN) → score → if high and external: create a **block IoC** in Defender and/or push a deny rule to the perimeter firewall (Palo Alto/Fortinet connector) with an **expiry** → comment with evidence.
- **Senior notes:** Always set a TTL on blocks to avoid permanent rule sprawl; never block private/corp ranges; whitelist known-good infrastructure.

### 12.4 Host isolation on EDR detection

- **Trigger:** High-severity Defender incident with a Device entity.
- **Logic:** Enrich device (owner, criticality tag) → post approval to Teams with full context → on approve: `isolateMachine` (Defender) → trigger AV scan → ticket → comment. On reject: comment and leave for manual handling.
- **Senior notes:** Never auto-isolate domain controllers / critical servers; use device tags to drive an allow/deny decision. Provide an un-isolate playbook too.

### 12.5 Enrichment-only playbook (foundation for everything)

- **Trigger:** Incident creation (auto via automation rule).
- **Logic:** For each entity, gather TI, sign-in logs, geo, user manager, device owner; compute a simple risk score; write a single consolidated **incident comment**; tag severity. Takes no action.
- **Senior notes:** This is the highest-ROI, lowest-risk automation. Ship this first to build SOC trust before automating any containment.

### 12.6 Ticketing / case sync

- **Trigger:** Incident create/update.
- **Logic:** Create/Update ServiceNow/Jira ticket; map Sentinel severity/status to the ITSM workflow; two-way sync status via an update playbook + automation rule on incident change.
- **Senior notes:** Idempotency via stored external ticket ID in an incident tag/comment; avoid update loops (incident update → ticket update → incident update ...).

---

## 13. Anti-patterns and gotchas

- **Auto-running high-impact actions** without approval or scoping (mass account disable from a noisy rule). Blast radius first.
- **Hardcoding** workspace IDs, recipients, secrets → undeployable and insecure.
- **One mega-playbook** doing everything → unmaintainable, hard to test. Compose small playbooks.
- **Ignoring throttling** — Graph and connector 429s; not honoring `Retry-After`.
- **No failure path** — silent failures mean the SOC believes an action happened when it did not.
- **Editing prod in the portal** → drift from source control.
- **Variables everywhere** → kills parallelism; prefer `Compose`/outputs.
- **Update loops** between Sentinel and ITSM/automation rules.
- **Confusing `revokeSignInSessions` with full containment** (it does not reset the password).
- **Over-permissioned managed identity** (`Directory.ReadWrite.All` when you only need `User.RevokeSessions.All`).
- **No timeout on approvals/Until loops** → runs hang for days and cost money.

---

## 14. Interview preparation

**Conceptual questions you should nail:**

- Difference between automation rules and playbooks, and when to use each.
- The three Sentinel trigger types and what each provides.
- Consumption vs Standard Logic Apps; stateful vs stateless.
- How playbook authentication should work (managed identity > SP > OAuth) and why.
- How you would design containment with human-in-the-loop and why blast radius matters.
- How `runAfter` enables try/catch/finally; retry policies and throttling.
- How you achieve idempotency.
- RBAC: which roles a playbook identity and an analyst need.
- CI/CD for playbooks (ARM/Bicep, environments, connection resources).

**Scenario questions (think out loud, structure the answer):**

- "A user is phished — walk me through the playbook." → enrich → confirm risky user → revoke sessions + reset password + disable + CA block (with approval) → notify → document; mention idempotency and that revoke alone is insufficient.
- "Detection is noisy and your auto-disable playbook locked out 200 users — what went wrong and how do you fix it?" → no scoping/approval/blast-radius control; add conditions in automation rule, approval step, exclusion lists, and a kill switch.
- "How do you take playbooks to production safely?" → source control, parameterization, environments, PR review, smoke tests, monitoring, least-privilege identity.

**Signals interviewers look for:** you talk about *risk and blast radius*, *least privilege*, *idempotency*, *observability*, and *human-in-the-loop* — not just "I connected box A to box B."

---

## 15. Glossary

- **SOAR** — Security Orchestration, Automation and Response.
- **Playbook** — a Sentinel-triggered Azure Logic App.
- **Automation rule** — Sentinel-native routing/decision layer that can run playbooks.
- **Entity** — an artifact in an incident (account, IP, host, file hash, URL).
- **Managed identity** — an Entra identity for an Azure resource, used to authenticate without secrets.
- **WDL** — Workflow Definition Language, the JSON behind a Logic App.
- **IoC** — Indicator of Compromise (hash, IP, domain, URL).
- **MTTD/MTTR** — Mean Time To Detect / Respond.
- **Idempotency** — re-running produces the same end state without duplicate side effects.
- **Blast radius** — the scope of impact if an automated action runs incorrectly.

---

*This document is a living reference. Pair it with the playbook diagrams under `playbooks/` and keep both in source control.*
