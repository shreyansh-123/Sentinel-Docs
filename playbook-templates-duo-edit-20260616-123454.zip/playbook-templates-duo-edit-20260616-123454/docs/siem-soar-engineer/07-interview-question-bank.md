# 07 — Interview Question Bank (with model answers)

> Microsoft-bar SIEM/SOAR interview prep. Practice answering out loud; structure every answer.

## A. KQL

**Q: Default `join` kind in KQL and why it matters?**
A: `innerunique` — it dedupes keys on the **left** table before joining, which can silently drop rows you expected. Always specify `kind=inner` (or the kind you mean) in production queries.

**Q: Find accounts with a failed sign-in burst that also had a success in the window.**
A: Summarize failures by account/IP/`bin()`, threshold it, then `join kind=inner` to successful sign-ins on the account. Filter time first, project early.

**Q: `has` vs `contains`?**
A: `has` matches whole terms using the term index — fast. `contains` is a substring scan — slow, especially with leading wildcards. Prefer `has`.

**Q: How do you get the latest record per entity?**
A: `summarize arg_max(TimeGenerated, *) by Entity`.

## B. Detection engineering

**Q: When NRT vs Scheduled?**
A: NRT for time-critical, low-latency detections (~1 min) with its constraints (single table, limited operators). Scheduled for everything else and for complex joins/aggregations.

**Q: Why is entity mapping critical?**
A: Entities power the investigation graph, alert grouping, and feed playbooks. Without mapping you can't group, can't auto-respond, and lose investigation context.

**Q: A rule fires 200 incidents/day, all benign. What do you do?**
A: Baseline historically, add allow-list/watchlist exclusions via `leftanti`, switch to per-entity dynamic thresholds, enable grouping + suppression, and if still noisy, retire it — chronic FPs erode analyst trust.

**Q: How do you ensure detection coverage?**
A: Tag rules with MITRE ATT&CK and use the coverage view to find gaps across tactics; prioritize by threat model and crown-jewel assets.

## C. Data & cost

**Q: How do you reduce Sentinel cost without losing security value?**
A: Filter noise at ingestion with DCR transforms, tier verbose low-value logs to Basic/Auxiliary, set per-table retention + archive, use commitment tiers, avoid duplicate ingestion, and push routing into (free) automation rules.

**Q: What is ASIM and why use it?**
A: A normalized schema; detections written against ASIM parsers work across many sources (firewall/proxy/cloud), giving source-agnostic coverage and portability.

**Q: What does a DCR do?**
A: Defines what AMA collects, optional ingestion-time KQL transformation (filter/mask/route), and the destination — a key cost and data-quality control point.

## D. SOAR / playbooks

**Q: Automation rule vs playbook?**
A: Automation rule is the native routing/decision layer (assign, tag, severity, close, run playbooks in order, conditions). Playbook (Logic App) is the doing layer with external calls and complex logic. Keep decisions in rules, logic in playbooks.

**Q: Three Sentinel trigger types?**
A: Incident (full context, most playbooks), Alert (per-alert enrichment), Entity (analyst-initiated on one entity).

**Q: How should a playbook authenticate?**
A: Managed identity (preferably user-assigned) > service principal with Key Vault secret > OAuth delegated (avoid for production). Least privilege on the identity.

**Q: How do you make a playbook idempotent?**
A: Use a correlation key (incident ARM ID + action) to check for an existing artifact before creating/notifying, so re-runs don't duplicate side effects.

**Q: Walk through containing a compromised account.**
A: Enrich (sign-ins, TI, risk) → confirm risky user → with approval: `revokeSignInSessions` + password reset + `accountEnabled=false` + Conditional Access block → notify SOC + ticket → incident comment. Note revoke alone is insufficient (no password reset). Mention blast-radius/approval.

**Q: Your auto-disable playbook locked out 200 users from a noisy rule — what went wrong?**
A: No scoping/approval/blast-radius control. Fix: tighten the detection, add conditions in the automation rule, an approval step, exclusion watchlists for service/break-glass accounts, and a documented kill switch.

## E. Architecture & RBAC

**Q: Single vs multiple workspaces?**
A: Default to single (best correlation, lowest cost/ops). Split only for data residency, regulatory/billing separation, or RBAC isolation that table-level RBAC can't satisfy.

**Q: How do MSSPs manage many tenants?**
A: Azure Lighthouse for delegated cross-tenant management, cross-workspace queries, multi-workspace view, and detection-as-code deployed per tenant.

**Q: Which role does a playbook's identity need to comment on incidents?**
A: Microsoft Sentinel Responder (or Contributor) on the workspace/resource group, plus the specific downstream permission (e.g., Graph `User.RevokeSessions.All`).

## F. Operations / system design

**Q: How do you take detections and playbooks to production safely?**
A: Detection-as-code in git, parameterized ARM/Bicep/YAML, PR review, dev→test→prod promotion, smoke tests against synthetic incidents, monitoring (SentinelHealth, failed-run alerts, workbooks), least-privilege identities, and a kill switch.

**Q: Design a SOC detection+response pipeline for a new enterprise.** (think aloud)
A: Inventory sources & threat model → onboard data (AMA/connectors + DCR filtering, ASIM) → workspace/RBAC design → detections-as-code mapped to MITRE → automation rules for triage → enrichment playbook first, then graduated containment with approvals → monitoring/health + cost governance → iterate on FP/TP metrics.

## G. Rapid-fire facts

- AMA replaced MMA; DCRs drive AMA collection.
- `revokeSignInSessions` ≠ password reset.
- Fusion = ML multi-stage correlation, low tuning.
- Basic/Auxiliary logs = cheap, limited query, no scheduled alerts.
- Grouping + suppression = primary noise controls.
- `arg_max(TimeGenerated, *)` = latest full row.
- Playbook = Logic App; automation rule runs it.
