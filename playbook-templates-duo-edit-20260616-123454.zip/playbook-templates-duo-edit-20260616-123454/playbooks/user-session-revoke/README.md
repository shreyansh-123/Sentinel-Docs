# User Session Revoke Playbook

Manual SOC playbook to revoke a specific user's active sessions, notify the SOC team by email, and record the action in the Microsoft Sentinel incident comments.

## Trigger

- **Type:** Manual only
- **Initiated by:** SOC Analyst
- **Scope:** A specific target user

## Flow

1. **Manual trigger** by SOC analyst for a specific user.
2. **Identify target user** (user ID / UPN).
3. **Validate** the user exists and has an active session.
   - If no valid/active session: log and close, no action required.
4. **Revoke user session** (invalidate active sessions / force sign-out and reset tokens).
   - If revoke fails: escalate / retry manual revoke.
5. **Initiate email** to the SOC team with action, user, analyst, and timestamp.
6. **Update details** in the Sentinel incident comment section.
7. **Playbook complete.**

## Diagram

The flowchart is provided as a [diagrams.net](https://app.diagrams.net/) file: [`user-session-revoke-playbook.drawio`](./user-session-revoke-playbook.drawio).

To view or edit:
1. Open <https://app.diagrams.net/>.
2. Choose **Open Existing Diagram** and select the `.drawio` file, or use **File > Import from > Device**.
